package br.com.gabriel.franca.pw3hasfoodapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pw3HasfoodApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
