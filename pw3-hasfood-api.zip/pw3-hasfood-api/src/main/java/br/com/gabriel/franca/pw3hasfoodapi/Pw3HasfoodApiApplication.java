package br.com.gabriel.franca.pw3hasfoodapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pw3HasfoodApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Pw3HasfoodApiApplication.class, args);
	}

}
